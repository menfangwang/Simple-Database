//
//  Database.cpp
//  Simple_Database
//
//  Created by xiaolingtc on 3/16/16.
//  Copyright © 2016 xiaolingtc. All rights reserved.
//

#include "Database.hpp"
